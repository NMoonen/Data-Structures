import java.util.HashMap;

import textbook.LinkedBinaryTree;
import textbook.LinkedQueue;
import textbook.Position;

public class Assignment {

	/**
	 * Convert an arithmetic expression (in prefix notation), to a binary tree
	 * 
	 * Binary operators are +, -, * (i.e. addition, subtraction, multiplication)
	 * Anything else is assumed to be a variable or numeric value
	 * 
	 * Example: "+ 2 15" will be a tree with root "+", left child "2" and right
	 * child "15" i.e. + 2 15
	 * 
	 * Example: "+ 2 - 4 5" will be a tree with root "+", left child "2", right
	 * child a subtree representing "- 4 5" i.e. + 2 - 4 5
	 * 
	 * This method runs in O(n) time
	 * 
	 * @param expression
	 *            - an arithmetic expression in prefix notation
	 * @return BinaryTree representing an expression expressed in prefix
	 *         notation
	 * @throws IllegalArgumentException
	 *             if expression was not a valid expression
	 */
	public static LinkedBinaryTree<String> prefix2tree(String expression) throws IllegalArgumentException {
		if (expression == null) {
			throw new IllegalArgumentException("Expression string was null");
		}
		// break up the expression string using spaces, into a queue
		LinkedQueue<String> tokens = new LinkedQueue<String>();
		for (String token : expression.split(" ")) {
			tokens.enqueue(token);
		}
		// recursively build the tree
		return prefix2tree(tokens);
	}
	
	/**
	 * Recursive helper method to build a tree representing an arithmetic
	 * expression in prefix notation, where the expression has already been
	 * broken up into a queue of tokens
	 * 
	 * @param tokens
	 * @return
	 * @throws IllegalArgumentException
	 *             if expression was not a valid expression
	 */
	private static LinkedBinaryTree<String> prefix2tree(LinkedQueue<String> tokens) throws IllegalArgumentException {
		LinkedBinaryTree<String> tree = new LinkedBinaryTree<String>();

		// use the next element of the queue to build the root
		if (tokens.isEmpty()) {
			throw new IllegalArgumentException("String was not a valid arithmetic expression in prefix notation");
		}
		String element = tokens.dequeue();
		tree.addRoot(element);

		// if the element is a binary operation, we need to build the left and
		// right subtrees
		if (element.equals("+") || element.equals("-") || element.equals("*")) {
			LinkedBinaryTree<String> left = prefix2tree(tokens);
			LinkedBinaryTree<String> right = prefix2tree(tokens);
			tree.attach(tree.root(), left, right);
		}
		// otherwise, assume it's a variable or a value, so it's a leaf (i.e.
		// nothing more to do)

		return tree;
	}
	
	/**
	 * Test to see if two trees are identical (every position in the tree stores the same value)
	 * 
	 * e.g. two trees representing "+ 1 2" are identical to each other, but not to a tree representing "+ 2 1"
	 * @param a
	 * @param b
	 * @return true if the trees have the same structure and values, false otherwise
	 */
	public static boolean equals(LinkedBinaryTree<String> a, LinkedBinaryTree<String> b) {
		return equals(a, b, a.root(), b.root());
	}

	/**
	 * Recursive helper method to compare two trees
	 * @param aTree one of the trees to compare
	 * @param bTree the other tree to compare
	 * @param aRoot a position in the first tree
	 * @param bRoot a position in the second tree (corresponding to a position in the first)
	 * @return true if the subtrees rooted at the given positions are identical
	 */
	private static boolean equals(LinkedBinaryTree<String> aTree, LinkedBinaryTree<String> bTree,
								  Position<String> aRoot, Position<String> bRoot) {
		//if either of the positions is null, then they are the same only if they are both null
		if(aRoot == null || bRoot == null) {
			return (aRoot == null) && (bRoot == null);
		}
		//first check that the elements stored in the current positions are the same
		String a = aRoot.getElement();
		String b = bRoot.getElement();
		if((a==null && b==null) || a.equals(b)) {
			//then recursively check if the left subtrees are the same...
			boolean left = equals(aTree, bTree, aTree.left(aRoot), bTree.left(bRoot));
			//...and if the right subtrees are the same
			boolean right = equals(aTree, bTree, aTree.right(aRoot), bTree.right(bRoot));
			//return true if they both matched
			return left && right;
		}
		else {
			return false;
		}
	}
	
	/**
	 * Recursive helper method to check whether a tree is a valid binary tree
	 * @param tree is the tree to check
	 * @param check is a position in the tree
	 * @throws IllegalArgumentException 
	 * 					if the tree is not a valid binary tree
	 */
	private static void checkValidity(LinkedBinaryTree<String> tree, Position<String> check) throws IllegalArgumentException{
		//Check whether leaf nodes do not contain an operator as element
		if(tree.isExternal(check)){
			if(check.getElement().equals("*")||check.getElement().equals("+")|| check.getElement().equals("-")){
				throw new IllegalArgumentException("Operator without values or variables");
			}
		}
		//Check whether nodes with an operator as element have to children
		if(check.getElement().equals("*") || check.getElement().equals("+") || check.getElement().equals("-")){
			if(tree.left(check)== null || tree.right(check) == null){
			throw new IllegalArgumentException("One value or variable is missing");
			}
		}
		//Check whether internal nodes have an operator as element
		if(tree.isInternal(check)){
			if(!check.getElement().equals("*") && !check.getElement().equals("-") && !check.getElement().equals("+")){
				throw new IllegalArgumentException("Value or variable without an operator");
			}
		}
		//Check whether a position contains an element
		if(check.getElement() == null){
			throw new IllegalArgumentException("Position contains no element");
		}
		//Recursive calls on the children of an internal node
		if(tree.isInternal(check)){
			checkValidity(tree, tree.left(check));
			checkValidity(tree, tree.right(check));
		}
	}
	
	/**
	 * Given a tree, this method should output a string for the corresponding
	 * arithmetic expression in prefix notation, without (parenthesis) (also
	 * known as Polish notation)
	 * 
	 * Example: A tree with root "+", left child "2" and right child "15" would
	 * be "+ 2 15" Example: A tree with root "-", left child a subtree
	 * representing "(2+15)" and right child "4" would be "- + 2 15 4"
	 * 
	 * Ideally, this method should run in O(n) time
	 * 
	 * @param tree
	 *            - a tree representing an arithmetic expression
	 * @return prefix notation expression of the tree
	 * @throws IllegalArgumentException
	 *             if tree was not a valid expression
	 */
	public static String tree2prefix(LinkedBinaryTree<String> tree) throws IllegalArgumentException {
		//Check whether the tree is not empty or an invalid binary tree
		if(tree==null){
			throw new IllegalArgumentException("Tree was empty");
		}
		checkValidity(tree, tree.root());
		//Call the recursive method to build a string expression
		StringBuilder expression = new StringBuilder();
		expression =tree2prefix(expression, tree, tree.root());
		return expression.toString();
	}
	
	/**
	 * Recursive helper method to build an arithmetic
	 * expression in prefix notation from a tree	 * 
	 * @param expression is the string representing the arithmetic expression
	 * @param tree is the tree for which the expression is the output
	 * @param examine is the position to start building the expression
	 * @return prefix notation of the tree
	 */
	private static StringBuilder tree2prefix(StringBuilder expression, LinkedBinaryTree<String> tree, Position<String> examine){
		//Add the element to the string expression
		expression.append(examine.getElement());
		//If element is an operator, make a recursive call on the children
		if(examine.getElement().equals("+") || examine.getElement().equals("-") || examine.getElement().equals("*")){
			Position<String> examineLeft = tree.left(examine);
			//Build a string with element of the left child
			StringBuilder expressionLeft = new StringBuilder();
			expressionLeft = tree2prefix(expressionLeft, tree, examineLeft);
			Position<String> examineRight = tree.right(examine);
			//Build a string with element of the right child
			StringBuilder expressionRight = new StringBuilder(); 
			expressionRight = tree2prefix(expressionRight, tree, examineRight);
			//Append strings of children to expression with spaces
			expression.append(" ").append(expressionLeft).append(" ").append(expressionRight);
		}
		
		return expression;
	}

	/**
	 * Given a tree, this method should output a string for the corresponding
	 * arithmetic expression in infix notation with parenthesis (i.e. the most
	 * commonly used notation).
	 * 
	 * Example: A tree with root "+", left child "2" and right child "15" would
	 * be "(2+15)"
	 * 
	 * Example: A tree with root "-", left child a subtree representing "(2+15)"
	 * and right child "4" would be "((2+15)-4)"
	 * 
	 * Optionally, you may leave out the outermost parenthesis, but it's fine to
	 * leave them on. (i.e. "2+15" and "(2+15)-4" would also be acceptable
	 * output for the examples above)
	 * 
	 * Ideally, this method should run in O(n) time
	 * 
	 * @param tree
	 *            - a tree representing an arithmetic expression
	 * @return infix notation expression of the tree
	 * @throws IllegalArgumentException
	 *             if tree was not a valid expression
	 */
	public static String tree2infix(LinkedBinaryTree<String> tree) throws IllegalArgumentException {
		//Check whether the tree is not empty or an invalid binary tree
		if(tree == null){
			throw new IllegalArgumentException("Tree was empty");
		}
		checkValidity(tree, tree.root());
		
		StringBuilder infix = new StringBuilder();
		Position<String> root = tree.root();
		
		//The root is the only position and element is appended to the string
		if(tree.isExternal(root)){
			infix.append(tree.root().getElement());
		}
		
		//Root has children and helper method is called to build a string
		if(tree.isInternal(root)){
			infix  = tree2infix(infix, tree, root);
			}
		return infix.toString();
	}
	
	/**
	 * Recursive helper method to build an arithmetic
	 * expression in infix notation from a tree	 * 
	 * @param infix is the string representing the arithmetic expression
	 * @param tree is the tree for which the infix string is the output
	 * @param at is the position to start building the expression
	 * @return infix notation expression of the tree
	 */
	private static StringBuilder tree2infix(StringBuilder infix, LinkedBinaryTree<String> tree, Position<String> at) throws IllegalArgumentException{
		//If element is an operator, the position is internal and recursive calls are made on the children
		if (at.getElement().equals("+") || at.getElement().equals("-") || at.getElement().equals("*")){
			//Parentheses and elements are appended to string builder
			infix.append("(");
			StringBuilder atLeft = new StringBuilder();
			atLeft = tree2infix(infix, tree, tree.left(at));
			infix.append(at.getElement());
			StringBuilder atRight = new StringBuilder();
			atRight = tree2infix(infix, tree, tree.right(at));
			infix.append(")");

		}
		//Position is external
		else infix.append(at.getElement());
		
		return infix;
	}
	
	/**
	 * Given a tree, this method should simplify any subtrees which can be
	 * evaluated to a single integer value.
	 * 
	 * Ideally, this method should run in O(n) time
	 * 
	 * @param tree
	 *            - a tree representing an arithmetic expression
	 * @return resulting binary tree after evaluating as many of the subtrees as
	 *         possible
	 * @throws IllegalArgumentException
	 *             if tree was not a valid expression
	 */
	public static LinkedBinaryTree<String> simplify(LinkedBinaryTree<String> tree) throws IllegalArgumentException {
		//Check whether the tree is not null and a valid binary arithmetic tree
		if(tree == null){
			throw new IllegalArgumentException("Tree was empty");
		}
		checkValidity(tree, tree.root());
		//Base case for a tree with a root without children
		if(tree.isExternal(tree.root())){
			return tree;
		}
		//If the root has children, the helper method simplify is called
		tree = simplify(tree, tree.root());
		return tree;
	}
	
	/**
	 * Recursive helper method to simplify integer values in an arithmetic binary tree 
	 * @param tree is the binary tree to simplify
	 * @param calc is the position being evaluated for simplification
	 * @return simplified binary tree
	 */
	private static LinkedBinaryTree<String> simplify(LinkedBinaryTree<String> tree, Position<String> calc){
		
		int numLeft=0;
		int numRight=0;
		
		if(calc.getElement().equals("+") || calc.getElement().equals("-") || calc.getElement().equals("*")){
			//Recursive calls of simplify on left and right subtree when element at calc is an operator
			if(tree.isInternal(tree.left(calc))){
				simplify(tree, tree.left(calc));
			}
			if(tree.isInternal(tree.right(calc))){
				simplify(tree, tree.right(calc));
			}
			
			//Boolean assumes left and right children are integers
			//If not, exception is caught and boolean is false
			boolean twoValues = true;
			String left = tree.left(calc).getElement();
			try{
				numLeft = Integer.parseInt(left);
			}
			catch(NumberFormatException e){
				twoValues = false;
			}
			String right = tree.right(calc).getElement();
			try{
				numRight = Integer.parseInt(right);
			}
			catch(NumberFormatException e){
				twoValues = false;
			}
			
			//In case both children are integers, subtrees are simplified
			if(twoValues==true){
				if(calc.getElement().equals("+")){
					int change = numLeft + numRight;
					tree.set(calc, Integer.toString(change)); //Element at calc is changed to the result of the calculation
					tree.remove(tree.left(calc)); //Left and right children are removed
					tree.remove(tree.right(calc));
				}
				if(calc.getElement().equals("-")){
					int change = numLeft - numRight;
					tree.set(calc, Integer.toString(change));
					tree.remove(tree.left(calc));
					tree.remove(tree.right(calc));
				}
				if(calc.getElement().equals("*")){
					int change = numLeft * numRight;
					tree.set(calc, Integer.toString(change));
					tree.remove(tree.left(calc));
					tree.remove(tree.right(calc));
				}
			}
		
		}
		return tree;
		
	}

	/**
	 * This should do everything the simplify method does AND also apply the following rules:
	 *  * 1 x == x  i.e.  (1*x)==x
	 *  * x 1 == x        (x*1)==x
	 *  * 0 x == 0        (0*x)==0
	 *  * x 0 == 0        (x*0)==0
	 *  + 0 x == x        (0+x)==x
	 *  + x 0 == 0        (x+0)==x
	 *  - x 0 == x        (x-0)==x
	 *  - x x == 0        (x-x)==0
	 *  
	 *  Example: - * 1 x x == 0, in infix notation: ((1*x)-x) = (x-x) = 0
	 *  
	 * Ideally, this method should run in O(n) time (harder to achieve than for other methods!)
	 * 
	 * @param tree
	 *            - a tree representing an arithmetic expression
	 * @return resulting binary tree after applying the simplifications
	 * @throws IllegalArgumentException
	 *             if tree was not a valid expression
	 */
	public static LinkedBinaryTree<String> simplifyFancy(LinkedBinaryTree<String> tree) throws IllegalArgumentException {
		//Check whether the tree is not null and a valid binary arithmetic tree
		if(tree == null){
			throw new IllegalArgumentException("Tree was empty");
		}
		checkValidity(tree, tree.root());
		
		//Base case when the root has not children
		if(tree.isExternal(tree.root())){
			return tree;
		}
		//Call simplify on the tree to simplify integer values
		LinkedBinaryTree<String> simplifiedTree = simplify(tree, tree.root());
		//If the root has children, helper method simplifyFancy is called
		tree = simplifyFancy(simplifiedTree, tree.root());

		return tree;
	}
	
	/**
	 * Recursive helper method to simplify integer values and variables in an arithmetic binary tree 
	 * @param tree is the binary tree to simplify
	 * @param simple is the position being evaluated for fancy simplification
	 * @return binary tree in which integer values as well as variables are simplified
	 */
	private static LinkedBinaryTree<String> simplifyFancy(LinkedBinaryTree<String> simplifiedTree, Position<String> simple){
		
		//If the position simple has children, recursive calls of the helper method are made on the children
		if(simplifiedTree.isInternal(simple)){
			simplifyFancy(simplifiedTree, simplifiedTree.left(simple));
			simplifyFancy(simplifiedTree, simplifiedTree.right(simple));
		}
		
		//Check whether the children of simple are not null
		if(simplifiedTree.left(simple) != null && simplifiedTree.right(simple) != null){
			//Check whether element at simple is an operator, because only then simplification is possible
			if(simple.getElement().equals("+") || simple.getElement().equals("-") || simple.getElement().equals("*")){
		
				//Compare whether the value of one of the children is 0
				if(simplifiedTree.left(simple).getElement().equals("0") ||simplifiedTree.right(simple).getElement().equals("0")){
					//Call the helper method simple
					simplifiedTree = simple(simplifiedTree, simple);
					}
			
				//Compare whether the value of one of the children is 1
				else if(simplifiedTree.left(simple).getElement().equals("1") ||simplifiedTree.right(simple).getElement().equals("1") && simple.getElement().equals("*")){
					simplifiedTree = simple(simplifiedTree, simple);
					}
				
				//Compare whether the elements of the children are equal
				else if(simplifiedTree.left(simple).getElement().equals(simplifiedTree.right(simple).getElement()) && simple.getElement().equals("-")){
				simplifiedTree = simple(simplifiedTree, simple);
				}	
			}
		}
		
		return simplifiedTree;
	}
	
	/**
	 * Helper method to simplify variables and similar subtrees in an arithmetic binary tree 
	 * @param simplifiedTree is the binary tree to simplify
	 * @param simple is the position being evaluated for fancy simplification
	 * @return binary tree in which the variables or subtrees are simplified
	 */
	private static LinkedBinaryTree<String> simple(LinkedBinaryTree<String> simplifiedTree, Position<String> simple){
		
		//Possible simplifications if the operator is a multiplication sign
		if(simple.getElement().equals("*")){
			
			//One of the children has 1 as element
			if(simplifiedTree.left(simple).getElement().equals("1")){
				//Right child shifts to position of simple and simple is removed with its left child
				simplifiedTree.remove(simplifiedTree.left(simple));
				simplifiedTree.remove(simple);
			}
			else if(simplifiedTree.right(simple).getElement().equals("1")){
				//Left child shifts to position of simple and simple is removed with its right child
				simplifiedTree.remove(simplifiedTree.right(simple));
				simplifiedTree.remove(simple);
				} 
			
			//One of the children has 0 as element
			else if(simplifiedTree.left(simple).getElement().equals("0") ){
				removeNodes(simplifiedTree, simplifiedTree.right(simple)); //Nodes in the right subtree are removed
				simplifiedTree.remove(simplifiedTree.left(simple)); //Left child of simple is removed
				simplifiedTree.set(simple, "0"); //Element at simple is set to 0
				}
			
			else if(simplifiedTree.right(simple).getElement().equals("0")){
				removeNodes(simplifiedTree, simplifiedTree.left(simple)); //Nodes in the left subtree are removed
				simplifiedTree.remove(simplifiedTree.right(simple)); //Right child of simple is removed
				simplifiedTree.set(simple, "0"); //Element at simple is set to 0
			}
		}	
		
		//Possible simplifications if the operator is an addition sign	
		else if(simple.getElement().equals("+")){
				//One of the children of simple has value 0
				if(simplifiedTree.left(simple).getElement().equals("0")){
					//Right child shifts to the position of simple and simple and its left child are removed
					simplifiedTree.remove(simplifiedTree.left(simple)); 
					simplifiedTree.remove(simple); 
				}
				else if(simplifiedTree.right(simple).getElement().equals("0")){
					//Left child shifts to the position of simple and simple and its right child are removed
					simplifiedTree.remove(simplifiedTree.right(simple));
					simplifiedTree.remove(simple);
			}
		}
			
		//Possible simplifications if the operator is the subtraction sign
		else if(simple.getElement().equals("-")){
				
				//Simple's right child has 0 as element
				if(simplifiedTree.right(simple).getElement().equals("0")){
					//Simple's right child and simple are removed, so its left child shifts to its position
					simplifiedTree.remove(simplifiedTree.right(simple));
					simplifiedTree.remove(simple);
				}
				
				//Elements of simple's left and right child are the same
				else if(simplifiedTree.right(simple).getElement().equals(simplifiedTree.left(simple).getElement())){
					//Check whether the entire subtrees are equal with helper method equalSubTrees
					if(equalSubTrees(simplifiedTree, simplifiedTree.left(simple), simplifiedTree.right(simple)) == true){
						removeNodes(simplifiedTree, simplifiedTree.left(simple)); //Remove nodes in the left subtree
						removeNodes(simplifiedTree, simplifiedTree.right(simple)); ///Remove nodes in the right subtree
						simplifiedTree.set(simple, "0"); //Set element at simple to 0
					}
				}
			}
		return simplifiedTree;
	}
	
	/**
	 * Given a tree, a variable label and a value, this should replace all
	 * instances of that variable in the tree with the given value
	 * 
	 * Ideally, this method should run in O(n) time (quite hard! O(n^2) is easier.)
	 * 
	 * @param tree
	 *            - a tree representing an arithmetic expression
	 * @param variable
	 *            - a variable label that might exist in the tree
	 * @param value
	 *            - an integer value that the variable represents
	 * @return Tree after replacing all instances of the specified variable with
	 *         it's numeric value
	 * @throws IllegalArgumentException
	 *             if tree was not a valid expression, or either of the other
	 *             arguments are null
	 */
	public static LinkedBinaryTree<String> substitute(LinkedBinaryTree<String> tree, String variable, int value)
			throws IllegalArgumentException {
		//Check whether the tree or variable is null and whether the tree is a valid binary tree
		if(tree == null){
			throw new IllegalArgumentException("Tree is empty");
		}
		if(variable == null){
			throw new IllegalArgumentException("No variable");
		}
		checkValidity(tree, tree.root());
		//Convert the integer value into a string
		String v = Integer.toString(value);
		//Base case for a tree with only one position (the root)
		if(tree.isExternal(tree.root())){
			//When element at root is the same as the variable, replace it with the value;
			if(tree.root().getElement().equals(variable)){
				tree.set(tree.root(), v);
			}
		}
		//Call the helper method when the root has children
		if(tree.isInternal(tree.root())){
			tree = substituteVariable(tree, tree.root(), variable, v);
		}
		return tree;
	}
	
	/**
	 * Recursive helper method to replace the element at all positions with the variable as element with the value  
	 * @param tree is the tree of which the positions are examined 
	 * @param sub is the position that is being examined
	 * @param variable is the element that should be replaced
	 * @param v is the element that variable is replaced by
	 * @return binary tree in which all instances of 'variable' have been replaced by 'value'
	 */
	private static LinkedBinaryTree<String> substituteVariable(LinkedBinaryTree<String> tree, Position<String> sub, String variable, String v){
		//If the element at the position equals the variable, the value is set as the new element
		if(sub.getElement().equals(variable)){
			tree.set(sub, v);
		}
		//If the position is internal, recursive calls are made on the children
		if(tree.left(sub)!= null){
			substituteVariable(tree, tree.left(sub), variable, v);
		}
		if(tree.right(sub)!= null){
			substituteVariable(tree, tree.right(sub), variable, v);
		}
		return tree;
	}

	/**
	 * Given a tree and a a map of variable labels to values, this should
	 * replace all instances of those variables in the tree with the
	 * corresponding given values
	 * 
	 * Ideally, this method should run in O(n) expected time
	 * 
	 * @param tree
	 *            - a tree representing an arithmetic expression
	 * @param map
	 *            - a map of variable labels to integer values
	 * @return Tree after replacing all instances of variables which are keys in
	 *         the map, with their numeric values
	 * @throws IllegalArgumentException
	 *             if tree was not a valid expression, or map is null, or tries
	 *             to substitute a null into the tree
	 */
	public static LinkedBinaryTree<String> substitute(LinkedBinaryTree<String> tree, HashMap<String, Integer> map)
			throws IllegalArgumentException {
		//Check whether the tree or map is not null and whether the tree is a valid binary tree
		if(tree == null){
			throw new IllegalArgumentException("Tree was empty");
		}
		if(map == null){
			throw new IllegalArgumentException("Map is empty");
		}
		checkValidity(tree, tree.root());
		
		//Call the helper method to replace the variables in the map with the corresponding values
		tree = substitutes(tree, map, tree.root());
		
		return tree;
	}
	

	/**
	 * Recursive helper method to replace all tree instances containing variables from the map 
	 * by the corresponding value in the map  
	 * @param tree is the tree of which the positions are examined 
	 * @param map of variable labels to integer values
	 * @param replace is the position being examined
	 * @return binary tree in which all instances with variables from the map
	 * have been replaced by the corresponding value
	 */
	public static LinkedBinaryTree<String> substitutes(LinkedBinaryTree<String> tree, HashMap<String, Integer> map, Position<String> replace){
		//If the position has children, the helper method is called for those children
		if(tree.isInternal(replace)){
			substitutes(tree, map, tree.left(replace));
			substitutes(tree, map, tree.right(replace));
		}
		
		if(tree.isExternal(replace)){
			//Loop through variables in the set
			//Throw an exception when the variable or value is null
			if(map.containsKey(replace.getElement())){
				if(map.get(replace.getElement()) == null){
					throw new IllegalArgumentException("Value for the label is missing");
				}
			
				String v = Integer.toString(map.get(replace.getElement()));//Convert the Integer value into a string
				tree.set(replace, v);
				
			}
		}
		
		return tree;
	}

	/**
	 * Given a tree, identify if that tree represents a valid arithmetic
	 * expression (possibly with variables)
	 * 
	 * Ideally, this method should run in O(n) expected time
	 * 
	 * @param tree
	 *            - a tree representing an arithmetic expression
	 * @return true if the tree is not null and it obeys the structure of an
	 *              arithmetic expression. Otherwise, it returns false
	 */
	public static boolean isArithmeticExpression(LinkedBinaryTree<String> tree) {
		//Check whether tree is empty and return false if this is the case
		if(tree == null){
			return false;
		}
		//Check whether tree is a valid expression with helper method checkValidity
		//If the tree is invalid, an exception is thrown and caught and false is returned
		try{
		checkValidity(tree, tree.root());
		}
		catch(Exception e){
			return false;
		}
		//If the tree is a valid arithmetic expression, true is returned
		return true;
	}
	
	/**
	 * Recursive helper method to remove nodes that are descendants of p
	 * @param t is the tree of which nodes have to be removed
	 * @param p is the position that has to be removed
	 * @return tree with the positions removed
	 */
	private static LinkedBinaryTree<String> removeNodes(LinkedBinaryTree<String> t, Position<String> p){
		//If p is internal, recursively call removeNodes on its children
		if(t.isInternal(p)){
			t= removeNodes(t, t.left(p));
			t= removeNodes(t, t.right(p));
		}
		//If a node is external, remove it
		if(t.isExternal(p)){
			t.remove(p);
		}
		
		return t;
	}

	/**
	 * Recursive helper method to compare two subtrees
	 * @param subTree is the tree to compare
	 * @param subLeft is the position in the left subtree to compare
	 * @param subRight is the position in the right subtree to compare
	 * @return true if the subtrees rooted at the given positions are identical
	 */
	private static boolean equalSubTrees(LinkedBinaryTree<String> subTree, Position<String> subLeft, Position<String> subRight) {
		//if either of the positions is null, then they are the same only if they are both null
		if(subLeft == null || subRight == null) {
			return (subLeft == null) && (subRight == null);
		}
		//Check that the elements stored in subLeft and subRight are the same
		String eLeft = subLeft.getElement();
		String eRight = subRight.getElement();
		if((subLeft==null && subRight==null) || eLeft.equals(eRight)) {
			//Recursively check if the left subtrees are the same
			boolean left = equalSubTrees(subTree, subTree.left(subLeft), subTree.left(subRight));
			//Recursively check if the right subtrees are the same
			boolean right = equalSubTrees(subTree, subTree.right(subLeft), subTree.right(subRight));
			//Return true if they both matched
			return left && right;
		}
		else {
			return false;
		}
	}
}
