import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import textbook.LinkedBinaryTree;

public class TestAssignment {
	
	// Set up JUnit to be able to check for expected exceptions
	@Rule
	public ExpectedException thrown = ExpectedException.none();

	// Some simple testing of prefix2tree
	@Test(timeout = 100)
	public void testPrefix2tree() {
		
		LinkedBinaryTree<String> tree;
	
		tree = Assignment.prefix2tree("hi");
		assertEquals(1, tree.size());
		assertEquals("hi", tree.root().getElement());

		tree = Assignment.prefix2tree("+ 5 10");
		assertEquals(3, tree.size());
		assertEquals("+", tree.root().getElement());
		assertEquals("5", tree.left(tree.root()).getElement());
		assertEquals("10", tree.right(tree.root()).getElement());
		
		tree = Assignment.prefix2tree("- 5 10");
		assertEquals(3, tree.size());
		assertEquals("-", tree.root().getElement());
		assertEquals("5", tree.left(tree.root()).getElement());
		assertEquals("10", tree.right(tree.root()).getElement());
		
		tree = Assignment.prefix2tree("* 5 10");
		assertEquals(3, tree.size());
		assertEquals("*", tree.root().getElement());
		assertEquals("5", tree.left(tree.root()).getElement());
		assertEquals("10", tree.right(tree.root()).getElement());
				
		tree = Assignment.prefix2tree("+ 5 - 4 3");
		assertEquals(5, tree.size());
		assertEquals("+", tree.root().getElement());
		assertEquals("5", tree.left(tree.root()).getElement());
		assertEquals("-", tree.right(tree.root()).getElement());
		assertEquals("4", tree.left(tree.right(tree.root())).getElement());
		assertEquals("3", tree.right(tree.right(tree.root())).getElement());
		
		thrown.expect(IllegalArgumentException.class);
		tree = Assignment.prefix2tree("+ 5 - 4");
	}
	
	// example of using the Assignment.equals method to check that "- x + 1 2" simplifies to "- x 3"
	@Test(timeout = 100)
	public void testSimplify1() {
		LinkedBinaryTree<String> tree = Assignment.prefix2tree("- x + 1 2");
		tree = Assignment.simplify(tree);
		LinkedBinaryTree<String> expected = Assignment.prefix2tree("- x 3");
		assertTrue(Assignment.equals(tree, expected));
		
		tree = Assignment.prefix2tree("- + 2 15 4");
		tree = Assignment.simplify(tree);
		LinkedBinaryTree<String> expected1 = Assignment.prefix2tree("13");
		assertTrue(Assignment.equals(tree, expected1));
		
		tree = Assignment.prefix2tree("- + 2 15 c");
		tree = Assignment.simplify(tree);
		LinkedBinaryTree<String> expected2 = Assignment.prefix2tree("- 17 c");
		assertTrue(Assignment.equals(tree, expected2));
		
		tree = Assignment.prefix2tree("- - 2 2 c");
		tree = Assignment.simplify(tree);
		LinkedBinaryTree<String> expected3 = Assignment.prefix2tree("- 0 c");
		assertTrue(Assignment.equals(tree, expected3));
	}
	
	
	@Test(timeout = 100)
	public void testTree2Prefix(){
		LinkedBinaryTree<String> tree;
		
		//Test 1: test that a correct prefix notation is returned for a tree with only a root containing a variable
		tree = Assignment.prefix2tree("hi");
		String a = "hi";
		assertEquals(a, Assignment.tree2prefix(tree));
		
		//Test 2: test that a correct prefix notation is returned for a tree with only a root containing a value
		tree = Assignment.prefix2tree("1");
		String c = "1";
		assertEquals(c, Assignment.tree2prefix(tree));
		
		//Test 3: test that a correct prefix notation is returned for a tree with two children
		tree = Assignment.prefix2tree("+ 5 10");
		String b = "+ 5 10";
		assertEquals(b, Assignment.tree2prefix(tree));
		tree = Assignment.prefix2tree("+ 1 2");
		String e = "+ 1 2";
		assertEquals(e, Assignment.tree2prefix(tree));
		
		//Test 4: test that a correct prefix notation is returned for a tree with height>1
		tree = Assignment.prefix2tree("+ 1 - 2 3");
		String f = "+ 1 - 2 3";
		assertEquals(f, Assignment.tree2prefix(tree));
		tree = Assignment.prefix2tree("* - 1 + b 3 d");
		String g = "* - 1 + b 3 d";
		assertEquals(g, Assignment.tree2prefix(tree));
		
		//Test 5: test that an exception is thrown for invalid tree with only one child and no prefix is returned
		LinkedBinaryTree<String> invalidTree = new LinkedBinaryTree<String>();
		invalidTree.addRoot("-");
		invalidTree.addLeft(invalidTree.root(), "1");
		
		thrown.expect(IllegalArgumentException.class);
		String invalid = Assignment.tree2prefix(invalidTree);
		
		//Test 6: test that an exception is thrown for invalid tree with an operator is a leaf node
		LinkedBinaryTree<String> alsoInvalid = new LinkedBinaryTree<String>();
		alsoInvalid.addRoot("+");
		alsoInvalid.addLeft(alsoInvalid.root(), "1");
		alsoInvalid.addRight(alsoInvalid.root(), "+");
		thrown.expect(IllegalArgumentException.class);
		String notValid = Assignment.tree2prefix(alsoInvalid);
		
	}
	
	@Test(timeout = 100)
	public void testTree2Infix(){
		LinkedBinaryTree<String> tree;
		//Test 1: test that a correct infix notation is returned for a tree with only a root containing a variable
		tree = Assignment.prefix2tree("hi");
		String a = "hi";
		assertEquals(a, Assignment.tree2infix(tree));
		
		//Test 2: test that a correct infix notation is returned for a tree with only a root containing a value
		tree = Assignment.prefix2tree("1");
		String c = "1";
		assertEquals(c, Assignment.tree2infix(tree));
		
		//Test 3: test that a correct infix notation is returned for a tree of height 1
		tree = Assignment.prefix2tree("+ 5 10");
		String b = "(5+10)";
		assertEquals(b, Assignment.tree2infix(tree));
		tree = Assignment.prefix2tree("+ 1 2");
		String e = "(1+2)";
		assertEquals(e, Assignment.tree2infix(tree));
		
		//Test 4: test that a correct infix notation is returned for a tree with height>1
		tree = Assignment.prefix2tree("+ 1 - 2 3");
		String f = "(1+(2-3))";
		assertEquals(f, Assignment.tree2infix(tree));
		tree = Assignment.prefix2tree("* - 1 + b 3 d");
		String g = "((1-(b+3))*d)";
		assertEquals(g, Assignment.tree2infix(tree));
		
		//Test 5: test that an exception is thrown for an invalid tree with only one child and no infix notation is returned
		LinkedBinaryTree<String> invalidTree = new LinkedBinaryTree<String>();
		invalidTree.addRoot("-");
		invalidTree.addLeft(invalidTree.root(), "1");
		thrown.expect(IllegalArgumentException.class);
		String invalid = Assignment.tree2infix(invalidTree);
		
		//Test 6: test that an exception is thrown for an invalid tree with a leaf node containing an operator and no infix notation is returned
		LinkedBinaryTree<String> alsoInvalid = new LinkedBinaryTree<String>();
		alsoInvalid.addRoot("+");
		alsoInvalid.addLeft(alsoInvalid.root(), "1");
		alsoInvalid.addRight(alsoInvalid.root(), "+");
		thrown.expect(IllegalArgumentException.class);
		String notValid = Assignment.tree2infix(alsoInvalid);
	}
	
		@Test(timeout = 100)
		public void testSimplify(){
			//Test 1: test that a tree with only values simplifies to the root
			LinkedBinaryTree<String> tree = Assignment.prefix2tree("- + 2 15 4");
			Assignment.simplify(tree);
			LinkedBinaryTree<String> expected1 = Assignment.prefix2tree("13");
			assertTrue(Assignment.equals(tree, expected1));
			
			//Test 2: test that a tree with values and variables simplifies correctly
			tree = Assignment.prefix2tree("- + 2 15 c");
			Assignment.simplify(tree);
			LinkedBinaryTree<String> expected2 = Assignment.prefix2tree("- 17 c");
			assertTrue(Assignment.equals(tree, expected2));
			
			tree = Assignment.prefix2tree("- - 2 2 c");
			Assignment.simplify(tree);
			LinkedBinaryTree<String> expected3 = Assignment.prefix2tree("- 0 c");
			assertTrue(Assignment.equals(tree, expected3));
			
			//Test 3: test that a tree with values simplifies to 0
			tree = Assignment.prefix2tree("- * 2 4 + 6 2");
			Assignment.simplify(tree);
			LinkedBinaryTree<String> expected4 = Assignment.prefix2tree("0");
			assertTrue(Assignment.equals(tree, expected4));
			
			//Test 4: test that an exception is thrown for a tree that is null;
			tree = null;
			thrown.expect(IllegalArgumentException.class );
			Assignment.simplify(tree);
			
			//Test 5: test that simplify works on a large tree
			tree = Assignment.prefix2tree("+ 0 + 1 - + * 2 1 1 + * 2 1 1");
			tree = Assignment.simplify(tree);
			LinkedBinaryTree<String> expected5=Assignment.prefix2tree("1");
			assertTrue(Assignment.equals(tree, expected5));
		}
		@Test(timeout = 100)
		public void testSimplifyFancy(){
			//Test 1: test that 1*x=x and x*1=x
			LinkedBinaryTree<String> tree = Assignment.prefix2tree("* 1 x");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected = Assignment.prefix2tree("x");
			assertTrue(Assignment.equals(tree, expected));
			
			tree = Assignment.prefix2tree("* x 1");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected1 = Assignment.prefix2tree("x");
			assertTrue(Assignment.equals(tree, expected1));
			
			tree = Assignment.prefix2tree("* 1 a");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected9 = Assignment.prefix2tree("a");
			assertTrue(Assignment.equals(tree, expected9));
			
			//Test 2: test that 0*x=0 and x*0=0
			tree = Assignment.prefix2tree("* 0 x");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected2 = Assignment.prefix2tree("0");
			assertTrue(Assignment.equals(tree, expected2));
			
			tree = Assignment.prefix2tree("* x 0");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected3 = Assignment.prefix2tree("0");
			assertTrue(Assignment.equals(tree, expected3));
			
			//Test 3: test that x+0=x
			tree = Assignment.prefix2tree("+ x 0");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected4 = Assignment.prefix2tree("x");
			assertTrue(Assignment.equals(tree, expected4));
			
			//Test 4: test that a tree with only a root is not simplified
			tree = Assignment.prefix2tree("x");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected5 = Assignment.prefix2tree("x");
			assertTrue(Assignment.equals(tree, expected5));
			
			//Test 5: test that 0-x is not simplified
			tree = Assignment.prefix2tree("- 0 x");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected6 = Assignment.prefix2tree("- 0 x");
			assertTrue(Assignment.equals(tree, expected6));
			
			//Test 6: test that x-0 is simplified
			tree = Assignment.prefix2tree("- x 0");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected7 = Assignment.prefix2tree("x");
			assertTrue(Assignment.equals(tree, expected7));
			 
			//Test 7: test that x-x=0
			tree = Assignment.prefix2tree("- x x");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected8 = Assignment.prefix2tree("0");
			assertTrue(Assignment.equals(tree, expected8));
			
			//Test 8: test that simplifyFancy simplifies correctly after simplifying values
			tree = Assignment.prefix2tree("+ - 2 2 c");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected10 = Assignment.prefix2tree("c");
			assertTrue(Assignment.equals(tree, expected10));
			
			tree = Assignment.prefix2tree("+ - + 1 1 2 c");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected11 = Assignment.prefix2tree("c");
			assertTrue(Assignment.equals(tree, expected11));
			
			//Test 9: test that multiple simplifications are performed on one tree
			tree = Assignment.prefix2tree("- * 1 c + c 0");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected12 = Assignment.prefix2tree("0");
			assertTrue(Assignment.equals(tree, expected12));
			
			//Test 10: test that 1*c is simplified, but c+1 is not
			tree = Assignment.prefix2tree("- * 1 c + c 1");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected13 = Assignment.prefix2tree("- c + c 1");
			assertTrue(Assignment.equals(tree, expected13));
			
			//Test 11: test the rule 0*x for a tree with height>1
			tree = Assignment.prefix2tree("* 0 - a  b");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected14 = Assignment.prefix2tree("0");
			assertTrue(Assignment.equals(tree, expected14));
			
			//Test 12: test the rule x-x for a tree with height>1
			tree = Assignment.prefix2tree("- + 2 4 + 2 4");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected15 = Assignment.prefix2tree("0");
			assertTrue(Assignment.equals(tree, expected15));

			tree = Assignment.prefix2tree("- + x 1 + x 1");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected17 = Assignment.prefix2tree("0");
			assertTrue(Assignment.equals(tree, expected17));
			
			//Test 13: test the rule 1*x for a tree with height>1
			tree = Assignment.prefix2tree("* 1 + a b");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected16 = Assignment.prefix2tree("+ a b");
			assertTrue(Assignment.equals(tree, expected16));
			
			//Test 14: test the rule x+0 for a tree with height>1
			tree = Assignment.prefix2tree("+ + a b 0");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected18 = Assignment.prefix2tree("+ a b");
			assertTrue(Assignment.equals(tree, expected18));
			
			//Test 15: test the rule x-0 for a tree with height>1
			tree = Assignment.prefix2tree("- + a b 0");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected19 = Assignment.prefix2tree("+ a b");
			assertTrue(Assignment.equals(tree, expected19));
			
			//Test 16: test the rule 0+x for a tree with height>1
			tree = Assignment.prefix2tree("+ 0 + a b");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected20 = Assignment.prefix2tree("+ a b");
			assertTrue(Assignment.equals(tree, expected20));
			
			//Test 17: test the rule x-x for a tree with height>1
			tree = Assignment.prefix2tree("- + - a c b + - a c b");
			tree= Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected21 = Assignment.prefix2tree("0");
			assertTrue(Assignment.equals(tree, expected21));
			
			//Test 18: test the rule 1*x for a tree with height>1
			tree = Assignment.prefix2tree("* 1 + 3 + b a");
			tree = Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> expected22 = Assignment.prefix2tree("+ 3 + b a");
			assertTrue(Assignment.equals(tree, expected22));
			
			//Test 19: test that an exception is thrown for an invalid tree
			LinkedBinaryTree<String> invalid = new LinkedBinaryTree<String>();
			invalid.addRoot("+");
			invalid.addLeft(invalid.root(), "x");
			invalid.addRight(invalid.root(), "*");
			thrown.expect(IllegalArgumentException.class);
			Assignment.simplify(invalid);
		}

		@Test(timeout=100)
		public void testSubstitute(){
			//Test 1: test that a variable is substituted by a value
			LinkedBinaryTree<String> tree = Assignment.prefix2tree("- 1 c");
			tree = Assignment.substitute(tree, "c", 5);
			LinkedBinaryTree<String> expected = Assignment.prefix2tree("- 1 5");
			assertTrue(Assignment.equals(tree, expected));
			
			//Test 2: test that incorrect variables are not substituted
			tree = Assignment.prefix2tree("- 1 b");
			tree = Assignment.substitute(tree, "c", 5);
			LinkedBinaryTree<String> expected1 = Assignment.prefix2tree("- 1 b");
			assertTrue(Assignment.equals(tree, expected1));
			
			//Test 3: test that multiple variables are substituted
			tree = Assignment.prefix2tree("+ c - c c");
			tree = Assignment.substitute(tree, "c", 5);
			LinkedBinaryTree<String> expected3 = Assignment.prefix2tree("+ 5 - 5 5");
			assertTrue(Assignment.equals(tree, expected3));
			
			//Test 4: test that different variables are substituted correctly
			tree = Assignment.prefix2tree("* + a 2 * b 3");
			tree = Assignment.substitute(tree, "a", 4);
			tree = Assignment.substitute(tree, "b", 7);
			LinkedBinaryTree<String> expected4 = Assignment.prefix2tree("* + 4 2 * 7 3");
			assertTrue(Assignment.equals(tree, expected4));
		}
		
		@Test 
		public void testSubstituteMap(){
			//Test 1: test a variable is correctly substituted
			LinkedBinaryTree<String> tree = Assignment.prefix2tree("- 1 c");
			HashMap<String, Integer> map = new HashMap<String, Integer>();
			map.put("c", 5);
			tree = Assignment.substitute(tree, map);
			LinkedBinaryTree<String> expected = Assignment.prefix2tree("- 1 5");
			assertTrue(Assignment.equals(tree, expected));
			
			//Test 2: test that other variables are not substituted
			tree = Assignment.prefix2tree("- 1 b");
			tree = Assignment.substitute(tree, map);
			LinkedBinaryTree<String> expected1 = Assignment.prefix2tree("- 1 b");
			assertTrue(Assignment.equals(tree, expected1));
			
			map.put("a", 1);
			map.put("b", 5);
			map.put("c", 3);
			//Test 3: test that the correct variable is substituted with the correct value
			tree = Assignment.prefix2tree("+ c - a b");
			tree = Assignment.substitute(tree, map);
			LinkedBinaryTree<String> expected2 = Assignment.prefix2tree("+ 3 - 1 5");
			assertTrue(Assignment.equals(tree, expected2));
			
			//Test 4: test that an exception is thrown when the map is null
			map=null;
			tree= Assignment.prefix2tree("- 1 c");
			thrown.expect(IllegalArgumentException.class);
			Assignment.substitute(tree, map);
			
		}
		
		@Test(timeout=100)
		public void testIsArithmeticExpression(){
			//Test 1: test that an empty tree is invalid
			LinkedBinaryTree<String> tree = null;
			assertFalse(Assignment.isArithmeticExpression(tree));
			
			//Test 2: test that a tree with only a root with a value or variable is valid
			tree = Assignment.prefix2tree("5");
			assertTrue(Assignment.isArithmeticExpression(tree));
			tree=Assignment.prefix2tree("abc");
			assertTrue(Assignment.isArithmeticExpression(tree));
			
			//Test 3: test that a tree with only a root containing an operator is invalid
			LinkedBinaryTree<String> falseRoot = new LinkedBinaryTree<String>();
			falseRoot.addRoot("+");
			assertFalse(Assignment.isArithmeticExpression(falseRoot));
			
			//Test 4: test that a tree with nodes with an operator as element and 2 children is valid
			tree=Assignment.prefix2tree("* + 1 2 - 3 5");
			assertTrue(Assignment.isArithmeticExpression(tree));
			
			//Test 5: test that a tree with nodes with only one child is invalid
			LinkedBinaryTree<String> childMissing = new LinkedBinaryTree<String>();
			childMissing.addRoot("*");
			childMissing.addLeft(childMissing.root(), "-");
			childMissing.addRight(childMissing.root(), "+");
			childMissing.addRight(childMissing.right(childMissing.root()), "1");
			childMissing.addLeft(childMissing.left(childMissing.root()), "d");
			assertFalse(Assignment.isArithmeticExpression(childMissing));
			
			//Test 6: test that a tree with two children and a value or variable as element is invalid
			LinkedBinaryTree<String> invalidElement = new LinkedBinaryTree<String>();
			invalidElement.addRoot("8");
			invalidElement.addLeft(invalidElement.root(), "4");
			invalidElement.addRight(invalidElement.root(), "6");
			assertFalse(Assignment.isArithmeticExpression(invalidElement));
			invalidElement.set(invalidElement.root(), "f");
			assertFalse(Assignment.isArithmeticExpression(invalidElement));
		}
		
		@Test (timeout = 100)
		public void testSubstituteSimplifyFancy(){
			//Test that a tree is simplified correctly after substitution
			LinkedBinaryTree<String> tree = Assignment.prefix2tree("* - 3 4 - x 3");
			Assignment.substitute(tree, "4", 3);
			
			Assignment.simplifyFancy(tree);
			LinkedBinaryTree<String> equal = Assignment.prefix2tree("0");
			assertTrue(Assignment.equals(tree, equal));
			
		
		}
}