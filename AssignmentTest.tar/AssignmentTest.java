import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class AssignmentTest {
	/**
	 * This AssignmentTest is based on code from TestAssignmentVisible.java
	 * Provided for the course INFO1105 Data Structures at the University of Sydney
	 * Accessed on September 12, 2017
	 */
	// Set up JUnit to be able to check for expected exceptions
	@Rule
	public ExpectedException thrown = ExpectedException.none();

	// This will make it a bit easier for us to make Date objects
	private static SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

	// This will make it a bit easier for us to make Date objects
	private static Date getDate(String s) {
		try {
			return df.parse(s);
		} catch (ParseException e) {
			e.printStackTrace();
			fail("The test case is broken, invalid SimpleDateFormat parse");
		}
		// unreachable
		return null;
	}

	// helper method to compare two Submissions using assertions
	private static void testHelperEquals(Submission expected, Submission actual) {
		assertEquals(expected.getUnikey(), actual.getUnikey());
		assertEquals(expected.getTime(), actual.getTime());
		assertEquals(expected.getGrade(), actual.getGrade());
	}

	// helper method to compare two Submissions using assertions
	private static void testHelperEquals(String unikey, Date timestamp, Integer grade, Submission actual) {
		assertEquals(unikey, actual.getUnikey());
		assertEquals(timestamp, actual.getTime());
		assertEquals(grade, actual.getGrade());
	}
	
	// helper method that adds a new appointment AND checks the return value is correct
	private static Submission testHelperAdd(SubmissionHistory history, String unikey, Date timestamp, Integer grade) {
		Submission s = history.add(unikey, timestamp, grade);
		testHelperEquals(unikey, timestamp, grade, s);
		return s;
	}
	
	private SubmissionHistory baseForTesting(){
		SubmissionHistory testing = new Assignment();
		testing.add("aaaa1111", getDate("2017/09/19 18:18:18"), 65);
		testing.add("aaaa1111", getDate("2017/09/20 18:18:00"), 70);
		testing.add("aabb1122", getDate("2017/09/19 18:18:18"), 80);
		testing.add("abcd1234", getDate("2017/08/20 08:18:00"), 55);
		testing.add("aaaa1111", getDate("2017/09/21 08:00:20"), 60);
		testing.add("defg8888", getDate("2017/04/15 19:04:20"), 80);
		return testing;
	}
	
	//Check whether the submission returned by the method add contains the expected unikey, timestamp and grade. 
	@Test
	public void testAdd(){
		SubmissionHistory testing = new Assignment();
		testHelperAdd(testing, "aaaa1111", getDate("2017/09/19 18:18:18"), 65);
		testHelperAdd(testing,"aaaa1111", getDate("2017/09/20 18:18:00"), 70);
		testHelperAdd(testing, "aabb1122", getDate("2017/09/19 18:18:18"), 80);
		testHelperAdd(testing, "abcd1234", getDate("2017/08/20 08:18:00"), 55);
	}
	
	//Check whether an exception is thrown when an illegal argument is passed to a method.
	@Test 
	public void testExceptions(){
		SubmissionHistory testing = new Assignment();
		//Exception when trying to remove a null submission.
		Submission one = null;
		thrown.expect(IllegalArgumentException.class);
		testing.remove(one);
		
		//Exceptions when one of the fields of the submission class is null.
		thrown.expect(IllegalArgumentException.class);
		testing.add(null, getDate("2017/05/06 15:06:04"), 75);
		thrown.expect(IllegalArgumentException.class);
		testing.add("abcd1111", null, 40);
		thrown.expect(IllegalArgumentException.class);
		testing.add("aacc8888", getDate("2017/08/08 14:15:16"), null);
		
		//Exceptions when unikey is null.
		thrown.expect(IllegalArgumentException.class);
		testing.getBestGrade(null);
		thrown.expect(IllegalArgumentException.class);
		testing.getSubmissionFinal(null);
		
		//Exceptions when at least one of the arguments for the getSubmissionBefore method is null.
		thrown.expect(IllegalArgumentException.class);
		testing.getSubmissionBefore(null, null);
		thrown.expect(IllegalArgumentException.class);
		testing.getSubmissionBefore(null, getDate("2017/08/08 14:15:16"));
		thrown.expect(IllegalArgumentException.class);
		testing.getSubmissionBefore("bcde5678", null);
	}
	
	//Tests checking whether the correct highest grade is returned after adding or removing submissions.
	@Test
	public void properHighestGrade(){
		SubmissionHistory testing = baseForTesting();
		Submission t1 = testing.add("aaaa1111", getDate("2017/03/14 17:22:44"), 85);
		Integer highestGrade = testing.getBestGrade("aaaa1111");
		assertEquals(new Integer(85), highestGrade);
		testing.remove(t1);
		highestGrade = testing.getBestGrade("aaaa1111");
		assertEquals(new Integer(70), highestGrade);
		Submission t2 = testing.add("aabb1234", getDate("2017/09/19 18:18:18"), 80);
		highestGrade = testing.getBestGrade("aabb1234");
		assertEquals(new Integer(80),highestGrade);
		Submission t3 = testing.add("aabb1234", getDate("2017/06/19 18:18:18"), 81);
		highestGrade = testing.getBestGrade("aabb1234");
		assertEquals(new Integer(81), highestGrade);
		assertNull(testing.getBestGrade("ccbb1221"));
		Submission t4= testing.add("klmn6789", getDate("2017/08/08 08:05:08"), 77);
		assertEquals(new Integer(77), testing.getBestGrade("klmn6789"));

	}
	
	//Tests checking whether the correct grade of the last submission is returned.
	@Test
	public void getLastGrade(){
		SubmissionHistory testing = baseForTesting();
		Submission last = testing.getSubmissionFinal("abcd1234");
		testHelperEquals("abcd1234", getDate("2017/08/20 08:18:00"), 55, last);
		testing.remove(last);
		assertNull(testing.getSubmissionFinal("abcd1234"));
	}
	
	//Tests checking whether the correct grade of the last submission on or before a deadline is returned.
	@Test
	public void getLastSubmission(){
		SubmissionHistory testing = baseForTesting();
		Submission last = testing.getSubmissionBefore("aaaa1111", getDate("2017/09/19 18:18:20"));
		testHelperEquals("aaaa1111", getDate("2017/09/19 18:18:18"), 65, last);
		last = testing.getSubmissionBefore("aaaa1111", getDate("2017/09/20 18:18:00")); 
		testHelperEquals("aaaa1111", getDate("2017/09/20 18:18:00"), 70, last);
	}
	
	//Tests checking whether the right unikeys are returned when checking which students achieved a highest grade.
	@Test
	public void listBestStudents(){
		SubmissionHistory testing = new Assignment();
		List<String> topStudents = testing.listTopStudents();
		assertTrue(topStudents.isEmpty());
		testing = baseForTesting();
		topStudents = testing.listTopStudents();
		List<String> expectedTop = Arrays.asList("aabb1122", "defg8888");
		assertEquals(expectedTop, topStudents);
	}
	
	//Tests checking whether the right unikeys are returned when checking which students performed worse on their last submission than on their best.
	@Test
	public void listRegressionStudents(){
		SubmissionHistory testing = new Assignment();
		List<String> regressionCases = testing.listRegressions();
		assertTrue(regressionCases.isEmpty());
		testing = baseForTesting();
		regressionCases = testing.listRegressions();
		List<String> expectedCases = Arrays.asList("aaaa1111");
		assertEquals(expectedCases, regressionCases);
		testing.add("aaaa1111", getDate("2017/09/22 08:00:20"), 70);
		regressionCases = testing.listRegressions();
		assertTrue(regressionCases.isEmpty());
	}
	
}